#!/bin/bash

##############################################################################################################
##
##  Install Jaguar admin software on all hosts in Jaguar cluster
##
##  ./install_jaguar_admin_on_all_hosts.sh/
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
hostfile="$JAGUAR_HOME/conf/cluster.conf"
allhosts=`cat $hostfile`

if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi

dname=`dirname $0`
if [[ "x$dname" = "x." ]] ; then
    dname=`pwd -P`
fi

ver=`basename $dname`
tarfile="${ver}.tar.gz"
tarpathfile="${dname}.tar.gz"

if [[ -f "$tarpathfile" ]]; then
	echo "Found file $tarpathfile, proceed ..."
else
	echo "file $tarpathfile not found, quit"
	exit 1
fi

for h in $allhosts
do
	echo "Install on host $h ..."
	ssh $h "mkdir -p ~/software"
	scp $tarpathfile $h:~/software
    ssh $h "cd ~/software; tar -zxf $tarfile; cd ${ver}; ./install.sh"
	echo " "
done

echo "Jaguar admin software has been started on all hosts"

