#!/usr/bin/python2

###########################################################################
##  Example program of Python for Jaguar
##
##  Copyright  DataJaguar Inc
##
###########################################################################
import jaguarpy, time, sys

jag = jaguarpy.Jaguar()
rc = jag.connect( "127.0.0.1", int(sys.argv[1]), "admin", "jaguarjaguarjaguar", "test" )
print ("Connected to Jaguar server rc=%d " % ( rc ) )
if rc == 0:
	print ("error=%s " % ( jag.error() ) )

jag.execute( "drop table if exists pt1; " );
jag.execute( "create table pt1 ( key: num int, value: speed int)"); 
jag.execute( "insert into pt1 values (1, 10)");
jag.execute( "insert into pt1 values (2, 20)");
jag.execute( "insert into pt1 values (3, 30)");

rc = jag.query( "show tables" );
while  jag.reply():
	jag.printRow();

time.sleep(3);
rc = jag.query( "select * from pt1" );
while jag.reply():
	jag.printRow();
	u=jag.getValue("num")
	a=jag.getValue("speed")
	iu=jag.getLong("num")
	fu=jag.getFloat("num")
	fd=jag.getDouble("num")
	nth=jag.getNthValue(2)
	s = 'num is ' + repr(u) + '  speed is ' + repr(a) + ' longu=' + repr(iu) + ' floatu=' + repr(fu)
	print (s)
	s = '2th value=' + repr(nth)
	print (s)

	js=jag.jsonString()
	s = 'json is ' + repr(js)
	print (s)


rc = jag.execute( "drop table t123;");
rc = jag.execute( "create table t123 (key: uid char(32), value: dept char(32) ); " );
rc = jag.execute( "insert into t123 values ( k1, v1 )");
rc = jag.execute( "insert into t123 values ( k2, v2 )");
rc = jag.execute( "insert into t123 values ( k3, v3 )");

rc = jag.query( "select * from t123 limit 10" );
while jag.reply():
	jag.printRow();

rc = jag.execute( "drop table t123;", 0 );

jag.close()
jag = None
