
JAGUAR_HOME=$HOME/jaguar
LIBPATH=$JAGUAR_HOME/lib
export LD_LIBRARY_PATH=$LIBPATH

g++ -v -I$JAGUAR_HOME/include -o example example.cc $JAGUAR_HOME/lib/libjaguar.a $JAGUAR_HOME/lib/libGeographic.a  -lpthread
