#!/bin/bash

##############################################################################################################
##
##  Server Installation Script  -- Install Jaguar Database on All Hosts in HOSTSFILE
##
##  ./install_jaguar_database_on_all_hosts.sh  -f <HOSTSFILE>  (Install to $HOME directory)
##  ./install_jaguar_database_on_all_hosts.sh  -f <HOSTSFILE>  [-d <INSTALL_DIR>]  (Install to INSTALL_DIR)
##
##############################################################################################################

function usage()
{
    echo "Usage: ./install_jaguar_database_on_all_hosts.sh [OPTION] -f HOSTFILE"
    echo "Install Jaguar database software on all hosts specified by -f HOSTFILE"
    echo "  [-help]           Display help text and exit."
    echo "  [-d DIRECTORY]    Install Jaguar in DIRECTORY. " 
    echo "                    If not provided, Jaguar will be installed in $HOME directory"
    echo "  [-f HOSTFILE]     Install Jaguar database on all the hosts in HOSTFILE."
    echo " "
    echo "In the HOSTFILE, each line must contain a host IP and its host name, separated by space(s)."
    echo " "
    echo "Example of HOSTFILE:"
    echo "192.168.2.110  node0"
    echo "192.168.2.111  node1"
    echo "192.168.2.112  node2"
    echo "192.168.2.113  node3"
    echo "192.168.2.114  node4"
    echo "192.168.2.115  node5"
    echo " "
    echo "All host IPs or names must be unique in the HOSTFILE."
}


dname=`dirname $0`
if [[ "x$dname" = "x." ]] ; then
    dname=`pwd -P`
fi

ver=`basename $dname`
tarfile="${ver}.tar.gz"
tarpathfile="${dname}.tar.gz"
jaguarhome=$HOME/jaguar
hostfile=""
dirInstall=""
options=""

if [[ ! -f "$tarpathfile" ]]; then
	echo "$tarpathfile is not found, exit"
	exit 1
fi

#echo "tarfile=[$tarfile] tarpathfile=[$tarpathfile]"

## Traverse all options given for this shell script
i=0
for arg in "$@"
do
    i=`expr $i + 1`
    case $arg in
        "-f")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                hostfile=${!i_next}
            else
				if [[ -f "$HOME/.jaghostfile" ]]; then
					echo "You have not provided hostfile. Installing on hosts in $HOME/.jaghostfile ..."
				else
					echo "You have not provided hostfile."
					usage
                	exit 1
				fi
            fi
            ;;

        "-d")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                jaguarhome=${!i_next}
            else
				usage
                exit 1
            fi
            ;;
        "-help")
            usage
            ;;
        "-h")
            usage
            ;;
        *)
            i_previous=`expr $i - 1`
            if [ ${!i_previous} != "-f" -a ${!i_previous} != "-d" ]
            then
            	usage
                exit 1
            fi
            ;;
    esac
done


JAGUAR_HOME=$jaguarhome
if [[ -e "$JAGUAR_HOME" ]]; then
    echo "OK, install jaguar files to $JAGUAR_HOME ..."
	echo $JAGUAR_HOME > $HOME/.jaguarhome
else
    echo "JAGUAR_HOME $JAGUAR_HOME does not exist, create it ..."
	if ! mkdir -p $JAGUAR_HOME; then
		echo "Unable to mkdir $JAGUAR_HOME"
		exit 1
	fi
fi

if [[ "x$JAGUAR_HOME" = "x$HOME" ]]; then
	echo "Wrong JAGUAR_HOME $JAGUAR_HOME exit"
	exit 1
fi

if [[ -f "$hostfile" ]]; then
    echo "OK, $hostfile is found"
	if [[ "x$hostfile" = "xcluster.conf" ]]; then
		echo "$hostfile is cluster.conf, error"
		exit 1
	fi

   	### check format of hostfile
	while read line; do
    	hm=`echo $line|grep -v '#'|awk '{print $2}'`
    	if [[ "x$hm" = "x" ]]; then
    		echo "$hostfile has incorrect format."
    		echo "It must contain  <IP_address>  <HostName> on each line."
			echo
    		echo "Example:"
    		echo "192.168.7.110  srv0"
    		echo "192.168.7.111  srv1"
    		echo "192.168.7.112  srv2"
    		echo "192.168.7.113  srv3"
			echo
    		exit 1
    	fi
	done < $hostfile

	awk '{print $1}' $hostfile > /tmp/cluster.conf
else
    echo "Hostfile $hostfile is not found, exit"
	usage
    exit 1
fi


### check hostfile is changed
((hostfilechanged=0))
if [[ -f $HOME/.jaghostfile ]]; then
	echo "$HOME/.jaghostfile exists"
	oldhosts=`grep -v '#' $HOME/.jaghostfile | awk '{print $1}' `
	if [[ "x$oldhosts" = "x" ]]; then
		echo "$HOME/.jaghostfile has old format, remove it ..."
		/bin/rm -f $HOME/.jaghostfile
	else
		newhosts=`grep -v '#' $hostfile | awk '{print $1}' `
    	for n in $newhosts; do
    		((exist=0))
    		for o in $oldhosts; do
    			if [[ "x$n" = "x$o" ]]; then
    				((exist=1))
    				break
    			fi
    		done
    
    		if (( exist==0 )); then
    			if [[ -f "$HOME/.jagsetupssh" ]]; then
    				/bin/rm -f $HOME/.jagsetupssh
    				echo "$HOME/.jagsetupssh is removed"
    			fi
    			echo "host $n is not in old hosts"
    			((hostfilechanged=1))
    			break
    		fi
    	done
    
    	for o in $oldhosts; do
    		((exist=0))
    		for n in $newhosts; do
    			if [[ "x$n" = "x$o" ]]; then
    				((exist=1))
    				break
    			fi
    		done
    
    		if (( exist==0 )); then
    			if [[ -f "$HOME/.jagsetupssh" ]]; then
    				/bin/rm -f $HOME/.jagsetupssh
    				echo "$HOME/.jagsetupssh is removed"
    			fi
    			echo "host $o is not in new hosts"
    			((hostfilechanged=1))
    			break
    		fi
    	done
	fi

fi


### save ssh setup flag
curd=`pwd`
cd $dname
if [[ ! -f "$HOME/.jagsetupssh" ]]; then
	echo "Set up ssh public keys on all hosts ..."
	if $dname/setupsshkeys -f $hostfile; then
		echo done > $HOME/.jagsetupssh
	fi
fi
cd $curd

### unpack new tar to ~/jaguardownload and use them
mkdir -p $HOME/jaguardownload
/bin/cp -f $tarpathfile $HOME/jaguardownload/
curd=`pwd`
cd $HOME/jaguardownload
tar -zxf $tarfile
cd $ver
/bin/cp -f server/jaguarstop_on_all_hosts.sh $JAGUAR_HOME/bin/
/bin/cp -f server/jaguarstatus_on_all_hosts.sh $JAGUAR_HOME/bin/
/bin/cp -f server/jaguarenv $JAGUAR_HOME/bin/
/bin/cp -f server/jaguarstop $JAGUAR_HOME/bin/
/bin/cp -f server/jaguarstart $JAGUAR_HOME/bin/
/bin/cp -f server/jaguarstatus $JAGUAR_HOME/bin/
cd $curd

### copy jaguarstop on all hosts
allhosts=`grep -v '#' $hostfile | awk '{print $2}' `
for h in $allhosts; do
	scp $JAGUAR_HOME/bin/jaguarenv $h:$JAGUAR_HOME/bin
	scp $JAGUAR_HOME/bin/jaguarstop $h:$JAGUAR_HOME/bin
	scp $JAGUAR_HOME/bin/jaguarstatus $h:$JAGUAR_HOME/bin
	scp $JAGUAR_HOME/bin/jaguarstart $h:$JAGUAR_HOME/bin
done


### if hosts file changes, stop and ask user to addcluster or export/import
if ((hostfilechanged==1)); then
	echo "You are trying to change the Jaguar server hosts."
	echo "In a production environment, it is not allowed to change server hosts."
	echo "If you are using more servers, please consider using the addcluster command"
	echo "If you are using fewer servers, please refer to the jagexport/jagimport command"
	/bin/rm -f /tmp/cluster.conf
	exit 1
fi


### stop all servers first
if [[ -f "$JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh" ]]; then
	echo "First stop Jaguar on all hosts ..."
	echo "$JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh"
	$JAGUAR_HOME/bin/jaguarstop_on_all_hosts.sh
	echo "======================================================"
	sleep 5

fi

randstr=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32|head -1`

echo "Install Jaguar on all other hosts ..."
cat $hostfile > $HOME/.jaghostfile

for h in $allhosts
do
	ssh $h "mkdir -p ~/jaguardownload"

	echo scp $tarpathfile $h:~/jaguardownload/
	scp $tarpathfile $h:~/jaguardownload/

    echo "ssh $h mkdir -p $JAGUAR_HOME; cd ~/jaguardownload; tar -zxf $tarfile; cd $ver; ./install.sh -d $JAGUAR_HOME -r $randstr"
    ssh $h "mkdir -p $JAGUAR_HOME; cd ~/jaguardownload; tar -zxf $tarfile; cd $ver; ./install.sh -d $JAGUAR_HOME -r $randstr"

	echo scp /tmp/cluster.conf $h:$JAGUAR_HOME/conf/
	scp /tmp/cluster.conf $h:$JAGUAR_HOME/conf/
done
/bin/rm -f /tmp/cluster.conf
echo "======================================================"



echo "Check program binaries on all hosts ..."
if $JAGUAR_HOME/bin/tools/check_binaries_on_all_hosts.sh; then
	echo "Program binaries are OK"
else
	echo "Program binaries have problem, exit"
	echo "Please update jaguar.bin/jaguar.exe jql.bin/jql/exe"
	exit 1
fi
echo "======================================================"

echo "Check PORT on all hosts ..."
$JAGUAR_HOME/bin/tools/check_config_on_all_hosts.sh PORT 
echo "======================================================"

echo "Check SERVER_TOKEN on all hosts ..."
$JAGUAR_HOME/bin/tools/check_config_on_all_hosts.sh SERVER_TOKEN
echo "======================================================"

echo "Check datacenter.conf on all hosts ..."
$JAGUAR_HOME/bin/tools/check_datacenter_on_all_hosts.sh 
echo "======================================================"


if [[ -f "$JAGUAR_HOME/bin/jaguarstart_on_all_hosts.sh" ]]; then
	echo "Finally start Jaguar on all hosts ..."
	echo "$JAGUAR_HOME/bin/jaguarstart_on_all_hosts.sh"
	$JAGUAR_HOME/bin/jaguarstart_on_all_hosts.sh
fi

