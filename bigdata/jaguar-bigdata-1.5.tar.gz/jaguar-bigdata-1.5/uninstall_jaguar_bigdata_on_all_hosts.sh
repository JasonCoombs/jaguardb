#!/bin/bash

errorMsg(){
    echo "Invalid option."
}

usage(){
    echo "Usage: uninstall_jaguar_bigdata_on_all_hosts.sh [OPTION]"
    echo "If no option is provided, uninstall kafka and hadoop on all hosts."
    echo "  [-hadoop]         Uninstall hadoop."
    echo "  [-kafka]          Uninstall kafka."
    echo "  [-spark]          Uninstall spark."
    echo "  [-help]           Display help text and exit."
}

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

uninstallHadoop=""
uninstallKafka=""
uninstallSpark=""
i=0
for arg in "$@"
do
    i=`expr $i + 1`
    case $arg in
        "-hadoop")
            uninstallHadoop="1"
            ;;
        "-kafka")
            uninstallKafka="1"
	    ;;
        "-spark")
            uninstallSpark="1"
            ;;
        "-h")
            usage
            ;;
        "-help")
            usage
            ;;
        *)
            errorMsg
            echo ""
            usage
	    exit 1
    esac
done

hostNames=("")
i=0
while read oneName
do
    hostNames[i]=$oneName
    i=`expr $i + 1`
done < hosts


if [ -z "$dirInstall" ]
then
    echo "None of bigdata software is installed."
    exit 1
else
    if [ ! -d "$dirInstall" ]
    then
        echo "None of bigdata software is installed."
        exit 1
    else
        if [ "x$uninstallKafka" = "x1" ]
        then
            for oneName in ${hostNames[@]}
            do
                ssh $oneName "rm -rf $dirInstall/jaguarkafka"
                echo "Finished uninstalling kafka  on $oneName"
            done
        fi

        if [ "x$uninstallHadoop" = "x1" ]
        then
            for oneName in ${hostNames[@]}
            do
                ssh $oneName "rm -rf $dirInstall/jaguarhadoop"
                echo "Finished uninstalling hadoop on $oneName"
            done
        fi

        if [ "x$uninstallSpark" = "x1" ]
        then
            for oneName in ${hostNames[@]}
            do
                ssh $oneName "rm -rf $dirInstall/jaguarspark"
		ssh $oneName "rm -rf $dirInstall/jaguarscala"
                echo "Finished uninstalling spark on $oneName"
            done
        fi

        if [ "x$uninstallKafka" = "x" -a "x$uninstallHadoop" = "x" -a "x$uninstallSpark" = "x" ]
        then
            for oneName in ${hostNames[@]}
            do
                ssh $oneName "rm -rf $dirInstall/jaguarkafka"
		ssh $oneName "rm -rf $dirInstall/jaguarzookeeper"
                echo "Finished uninstalling kafka  on $oneName"
                ssh $oneName "rm -rf $dirInstall/jaguarhadoop"
                echo "Finished uninstalling hadoop on $oneName"
                ssh $oneName "rm -rf $dirInstall/jaguarspark"
		ssh $oneName "rm -rf $dirInstall/jaguarscala"
                echo "Finished uninstalling spark on $oneName"
            done
        fi
    fi
fi
