#!/bin/bash

############################################################################
##  DataJaguar, Inc. All Rights Reserved
##
##  Installation script for installing Hadoop, Kafka, Spark, Zeppelin
##
##  Usage: ./install_jaguar_bigdata_on_all_hosts.sh [OPTION] -f HOSTFILE -PACKAGE
##
############################################################################

errorMsg(){
    echo "Invalid option."
    usage
}

usage(){
    echo
    echo "Usage: ./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE [-PACKAGE]"
    echo "-f HOSTFILE is mandatory. HOSTFILE contains all hosts where the packages will be installed."
    echo "If no packages are specified, then no packages will be installed."
    echo "[-PACKAGE] are as follows:"
    echo "  [-hadoop]         Install hadoop"
    echo "  [-kafka]          Install kafka"
    echo "  [-spark]          Install spark"
    echo "  [-zeppelin]       Install zeppelin"
    echo "  [-all]            Install hadoop, kafka, spark, zeppelin"
    echo "  [-help]           Display help text and exit."
    echo "  [-d DIRECTORY]    Install software in DIRECTORY. Default is under $HOME/"
    echo "                    Default: Hadoop files will be in $HOME/jaguarhadoop, Kafka in $HOME/jaguarkafka, etc."
    echo "   -f HOSTFILE      Required. Install software on the hosts in HOSTFILE."
    echo "      In the HOSTFILE each line contains one host:"
    echo "      For example:"
    echo "      node1"
    echo "      node2"
    echo "      node3"
    echo "      node4"
    echo " "
    echo "      node1 will be namenode1"
    echo "      node2 will be namenode2"
    echo "      node3 will be data node"
    echo "      node4 will be data node"
    echo
    echo "For example:"
    echo "./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE -hadoop"
    echo "./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE -hadoop -kafka"
    echo "./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE -hadoop -spark"
    echo "./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE -spark -zeppelin"
    echo "./install_jaguar_bigdata_on_all_hosts.sh -f HOSTFILE -all"
    echo
}

## dirTar is the directory where tar file is.
## dirInstall is the directory where specific packages are to be installed
## options is a string containing all options following ./jaginstaller when running ./jaginstaller.
## options will change with new options validated. For example, if $hostfile does exist, "-f $hostfile" will be appended to $options

pd=`pwd`
dirTar=`dirname $pd`
jaguarBigdataTarName="${pd##*/}.tar.gz"
hostfile=""
dirInstall=""
options=""


## Traverse all options given for this shell script
i=0
for arg in "$@"
do
    i=`expr $i + 1`
    case $arg in
        "-f")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                hostfile=${!i_next}
            else
                errorMsg
                exit 1
            fi

            if [ `expr substr "$hostfile" 1 1` = "-"  ]
            then
                echo "After -f, no host file provided."
                errorMsg
                exit 1
            fi
            ;;
        "-d")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]
            then
                dirInstall=${!i_next}
            else
                errorMsg
                exit 1
            fi

            if [ `expr substr "$dirInstall" 1 1` = "-"  ]
            then
                echo "After -d, no installation directory provided."
                errorMsg
                exit 1
            fi
            ;;
        "-help")
            usage
	        exit 1
            ;;
        "-h")
            usage
            exit 1
            ;;
        "-hadoop")
            options="$options -hadoop"
            hadoop="1";
            ;;
        "-kafka")
            options="$options -kafka"
            kafka="1"
            ;;
        "-spark")
            options="$options -spark"
            spark="1"
            ;;
        "-zeppelin")
            zeppelin="1"
            ;;
        "-all")
            hadoop="1";
            kafka="1"
            zeppelin="1"
            spark="1"
            options="$options -hadoop -kafka -spark"
            ;;
        *)
            i_previous=`expr $i - 1`
            if [ ${!i_previous} != "-f" -a ${!i_previous} != "-d" ]
            then
                errorMsg
                exit 1
            fi
            ;;
    esac
done

if [[ "x$hadoop" = "x" && "x$kafka" = "x" && "x$spark" = "x" && "x$zeppelin" = "x" ]]
then
    echo "You must provide a package or all packages to install"
    usage
    exit 1
fi

## If $hostfile is not provided or $hostfile does not exist, print usage message and exit
## $hostfile is mandatory.
if [ -z "$hostfile" ]
then
    echo "Host file is not provided. Please provide the host file."
    echo ""
    usage
    exit 1
else
    if [ ! -f "$hostfile" ]
    then
        echo "Host file $hostfile does not exist."
        usage
        exit 1
    fi
fi

## If dirInstall is not provided, install where Jaguar database is installed.
## If Jaguar database is not installed, install in $HOME.
## If dirInstall is provided, check if it exists. If not, print usage message and exit.
if [ -z "$dirInstall" ]
then
    dirInstall=$HOME
    echo "Installation directory is not provided. Installing packages in $HOME/ ..."
else
    if [ ! -d "$dirInstall" ]
    then
        echo "Installation directory provided does not exist. Please provide an existing directory for installation."
        echo " "
        usage
        exit 1
    fi
fi
options="$options -d $dirInstall"

## run setupsshkeys to set up ssh trust on hosts given in $hostfile
if [[ ! -f "$HOME/.jaghostfile" ]]; then
    ./setupsshkeys -f $hostfile
fi

## Read hostfile line by line and save all host to an array called hostNames
i=0
hostNames=("")
while read oneHost
do
    hostNames[i]=${oneHost%%" "*}
    i=`expr $i + 1`
done <$hostfile

hostfile=$pd/hosts
options="$options -f $hostfile"

## Kill currently running process(es)
if [ -z "$kafka" -a -z "$hadoop" -a -z "$spark" -a -z "$zeppelin" ]
then
    kafka=1
    hadoop=1
    spark=1
    zeppelin=1
fi

### setup JAVA_HOME on each host
echo "Please make sure JAVA_HOME, HADOOP_PREFIX, HADOOP_HOME, YARN_HOME env vars are setup on each host."

### check package/* exists
if [ "x$hadoop" = "x1" ]; then
    targzfile=`/bin/ls -rt package | grep hadoop | grep -v spark | grep gz|tail -1`
    if [ "x$targzfile" = "x" ]; then
    	echo "Error finding hadoop tar.gz file, abort"
	echo "Please copy your hadoop-x.x.x.tar.gz file in package directory and install again"
	exit 1
    fi
fi

if [ "x$kafka" = "x1" ]; then
    targzfile=`/bin/ls -rt package | grep kafka | grep gz|tail -1`
    if [ "x$targzfile" = "x" ]; then
    	echo "Error finding kafka tar.gz file, abort"
	echo "Please copy your kafka_x.x.x tar gz file in package directory and install again"
	exit 2
    fi
fi

if [ "x$kafka" = "x1" ]; then
    targzfile=`/bin/ls -rt package | grep spark | grep gz|tail -1`
    if [ "x$targzfile" = "x" ]; then
    	echo "Error finding spark tar.gz file, abort"
	echo "Please copy your spark-x.x.x tar gz file in package directory and install again"
	exit 3
    fi
fi


if [ "x$kafka" = "x1" ]; then
    targzfile=`/bin/ls -rt package | grep scala | grep gz`
    if [ "x$targzfile" = "x" ]; then
    	echo "Error finding scala tar.gz file, abort"
	echo "Please copy your scala-x.x.x tar gz file in package directory and install again"
	exit 4
    fi
fi


if [ "x$zeppelin" = "x1" ]; then
    targzfile=`/bin/ls -rt package | grep zeppelin | grep gz|tail -1`
    if [ "x$targzfile" = "x" ]; then
    	echo "Error finding zeppeline tar.gz file, abort"
	echo "Please copy your zeppelin-x.x.x tar gz file in package directory and install again"
	exit 4
    fi
fi


for oneHost in ${hostNames[@]}
do
    if [ "x-$kafka" = "x-1" ]
    then
        pid=""
        pid=`ssh $oneHost jps | grep -wi kafka | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
    fi
    
    if [ "x-$hadoop" = "x-1" ]
    then
        pid=`ssh $oneHost jps | grep -wi JournalNode | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps | grep -wi NameNode | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps | grep -wi DataNode | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps | grep -wi NodeManager | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps | grep -wi ResourceManager | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps| grep -wi DFSZKFailoverController | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
    fi
    
    if [ "x-$spark" = "x-1" ]
    then
        pid=`ssh $oneHost jps | grep -wi Worker | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
        pid=`ssh $oneHost jps | grep -wi Master | awk '{print $1}'`
        if [ -n "$pid" ]
        then
            ssh $oneHost "kill -9 $pid"
        fi
    fi
done

if [ "x-$zeppelin" = "x-1" ]
then
    pid=`jps | grep -wi ZeppelinServer | awk '{print $1}'`
    if [ -n "$pid" ]
    then
        kill -9 $pid
    fi 
    pid=`jps | grep -wi RemoteInterpreterServer | awk '{print $1}'`
    if [ -n "$pid" ]
    then
	kill -9 $pid
    fi
fi

## Install zeppelin on local server if needed
sourceFiles="source /etc/profile ; source /etc/bashrc ; source /etc/bash.bashrc"
sourceFiles="$sourceFiles ; source ~/.bashrc ; source ~/.bash_profile ; source ~/.profile"

if [ "x-$zeppelin" = "x-1" ]
then
    echo "Install zeppelin on local server..."
    $sourceFiles ;  ./jaginstaller -f $hostfile -d $dirInstall -zeppelin 2>/dev/null
fi

## Traverse all hosts in hostfile.
## (1) mkdir -p $dirTar if $dirTar does not exist in one host. $dirTar is the directory where tar file should be copied to.
## (2) Copy tar file to all other hosts in the same directory as the local host.
## (3) Extract tar file in $dirTar
## (4) Copy hostfile to all other hosts. (hostfile is already copied to $pd/hosts file in the local host.)
## (5) If installation directory ($dirInstall) does not exist, make that directory by mkdir -p $dirInstall
## The five steps above are only conducted if the host is not local host.
## (6) ./jaginstaller $options to install specific packages.

for hostName in ${hostNames[@]}
do
    echo "*** Begin installing package(s) on $hostName ***"

    ssh $hostName "/bin/mkdir -p $dirTar"
    echo "Copy $jaguarBigdataTarName to $hostName"
    scp $dirTar/$jaguarBigdataTarName $hostName:$dirTar
    echo "Extract $jaguarBigdataTarName"
    ssh $hostName "cd $dirTar ; tar -xzf $jaguarBigdataTarName" 2>/dev/null
    ssh $hostName "/bin/mkdir -p $dirInstall"
    echo "Copy hostfile to $hostName"
    scp $hostfile $hostName:$pd/hosts

    ssh $hostName "cd $pd ; $sourceFiles ;  ./jaginstaller $options" 2>/dev/null
    ssh $hostName "echo $dirInstall > $HOME/.jaguarbigdatahome"

    ssh $hostName "/bin/cp -f $pd/hosts         $dirInstall/jaguarkafka/config/hosts" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/start_kafka_on_all_hosts.sh       $dirInstall/jaguarkafka/bin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/stop_kafka_on_all_hosts.sh        $dirInstall/jaguarkafka/bin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/start_zookeeper_on_all_hosts.sh   $dirInstall/jaguarkafka/bin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/stop_zookeeper_on_all_hosts.sh    $dirInstall/jaguarkafka/bin/" 2>/dev/null

    ssh $hostName "/bin/cp -f $pd/hosts        $dirInstall/jaguarhadoop/etc/hadoop/hosts" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/start_hadoop_on_all_hosts.sh      $dirInstall/jaguarhadoop/sbin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/start_journalnode_on_all_hosts.sh $dirInstall/jaguarhadoop/sbin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/stop_journalnode_on_all_hosts.sh $dirInstall/jaguarhadoop/sbin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/format_hadoop_on_all_hosts.sh     $dirInstall/jaguarhadoop/sbin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/stop_hadoop_on_all_hosts.sh       $dirInstall/jaguarhadoop/sbin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/check_namenode_status.sh          $dirInstall/jaguarhadoop/sbin/" 2>/dev/null

    ssh $hostName "/bin/cp -f $pd/hosts       $dirInstall/jaguarspark/conf/hosts" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/start_spark_on_all_hosts.sh       $dirInstall/jaguarspark/bin/" 2>/dev/null
    ssh $hostName "/bin/cp -f $pd/stop_spark_on_all_hosts.sh        $dirInstall/jaguarspark/bin/" 2>/dev/null
    echo "*** Finished installing packages on $hostName ***"
    date
    echo
done
