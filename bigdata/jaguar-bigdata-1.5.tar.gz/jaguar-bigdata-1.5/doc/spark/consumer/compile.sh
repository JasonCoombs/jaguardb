#sbt clean package
sbt package

