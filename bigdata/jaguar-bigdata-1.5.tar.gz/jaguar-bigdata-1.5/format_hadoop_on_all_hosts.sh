#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hostNames=("")
i=0
while read oneName
do
    hostNames[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarhadoop/etc/hadoop/hosts

rm -rf $dirInstall/jaguarhadoop/data
mkdir -p $dirInstall/jaguarhadoop/data

for oneName in ${hostNames[@]}
do
    ssh $oneName "/bin/rm -rf $dirInstall/jaguarhadoop/data"
    ssh $oneName "/bin/mkdir -p $dirInstall/jaguarhadoop/data"
done

echo "Starting Journal Nodes for High Availability..."
for oneName in ${hostNames[@]}
do
    ssh $oneName "$dirInstall/jaguarhadoop/sbin/hadoop-daemon.sh start journalnode"
done

echo Y | ssh ${hostNames[0]} "$dirInstall/jaguarhadoop/bin/hdfs namenode -format"
echo Y | ssh ${hostNames[0]} "$dirInstall/jaguarhadoop/bin/hdfs zkfc -formatZK"
ssh ${hostNames[0]} "scp -r $dirInstall/jaguarhadoop/data ${hostNames[1]}:$dirInstall/jaguarhadoop/ "
