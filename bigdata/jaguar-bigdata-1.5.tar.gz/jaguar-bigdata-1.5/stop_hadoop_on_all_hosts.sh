#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hName=("")
i=0
while read oneName
do
    hName[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarhadoop/etc/hadoop/hosts

ssh ${hName[0]} $dirInstall/jaguarhadoop/sbin/stop-yarn.sh
ssh ${hName[0]} $dirInstall/jaguarhadoop/sbin/stop-dfs.sh
