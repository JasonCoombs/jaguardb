#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hostNames=("")
i=0
while read oneName
do
    hostNames[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarkafka/config/hosts

for oneName in ${hostNames[@]}
do
    ## Kill currently running Kafka process on each host
    pids=`ssh $oneName "jps" | grep -wi kafka | awk '{print $1}'`
    if [ ! -z "$pids" ]
    then
        echo "Stop running Kafka process on $oneName"
        ssh $oneName "kill -9 $pids"
    else
        echo "No Kafka process stopped on $oneName"
    fi
done
