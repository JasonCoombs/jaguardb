#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hname=("")
i=0
while read oneName
do
    hname[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarkafka/config/hosts

## Kill currently running Kafka process on each host
for oneName in ${hname[@]}
do
    pids=`ssh $oneName "jps" | grep -wi kafka | awk '{print $1}'`
    if [ ! -z "$pids" ]
    then
        echo "Stop running Kafka process on $oneName"
        ssh $oneName "kill -9 $pids"
    else
        echo "No Kafka process stopped on $oneName"
    fi
done

sleep 5

for oneName in ${hname[@]}
do
    echo "Start kafka on $oneName"
    ssh $oneName "mkdir -p $dirInstall/jaguarkafka/logs"
    ssh $oneName "nohup $dirInstall/jaguarkafka/bin/kafka-server-start.sh $dirInstall/jaguarkafka/config/server.properties  > $dirInstall/jaguarkafka/logs/start_kafka.log 2>&1 & "
done
