#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hostNames=("")
i=0
while read oneName
do
    hostNames[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarspark/conf/hosts

ssh ${hostNames[0]} "$dirInstall/jaguarspark/sbin/start-all.sh"
