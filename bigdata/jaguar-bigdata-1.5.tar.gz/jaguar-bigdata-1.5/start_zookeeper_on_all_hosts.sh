#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hostnames=("")
i=0
while read onename
do
    hostnames[i]=$onename
    i=`expr $i + 1`
done < $dirInstall/jaguarkafka/config/hosts

## Kill currently running ZooKeeper process on each host
for onename in ${hostnames[@]}
do
    pids=`ssh $onename "jps" | grep -wi quorumpeermain | awk '{print $1}'`
    if [ ! -z "$pids" ]
    then
        echo "Stop running Zookeeper process on $onename"
        ssh $onename "kill -9 $pids"
    else
        echo "No Zookeeper process stopped on $onename"
    fi
done

sleep 3

for onename in ${hostnames[@]}
do
    echo "Start zookeeper on $onename"
    ssh $onename "mkdir -p $dirInstall/jaguarkafka/logs"
    ssh $onename "nohup $dirInstall/jaguarkafka/bin/zookeeper-server-start.sh $dirInstall/jaguarkafka/config/zookeeper.properties  > $dirInstall/jaguarkafka/logs/start_zookeeper.log 2>&1 & "
done
