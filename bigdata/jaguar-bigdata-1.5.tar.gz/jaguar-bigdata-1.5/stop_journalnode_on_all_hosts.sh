#!/bin/sh

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

while read oneName
do
    ssh $oneName "$dirInstall/jaguarhadoop/sbin/hadoop-daemon.sh stop journalnode"
done < $dirInstall/jaguarhadoop/etc/hadoop/hosts

