#!/bin/sh

hdfs haadmin -getServiceState namenode1
hdfs haadmin -getServiceState namenode2


