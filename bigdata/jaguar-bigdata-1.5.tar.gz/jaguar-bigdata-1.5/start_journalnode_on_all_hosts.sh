#!/bin/sh

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

while read one
do
    ssh $one "$dirInstall/jaguarhadoop/sbin/hadoop-daemon.sh start journalnode"
done < $dirInstall/jaguarhadoop/etc/hadoop/hosts

