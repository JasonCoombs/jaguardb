#!/bin/bash

##########################################################################
##
## DataJaguar, Inc   All Rights Reserved
##
##########################################################################

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
    dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hname=("")
i=0
while read oneName
do
    hname[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarhadoop/etc/hadoop/hosts

ssh ${hname[0]} "$dirInstall/jaguarhadoop/sbin/start-dfs.sh"

ssh ${hname[0]} "$dirInstall/jaguarhadoop/sbin/start-yarn.sh"

ssh ${hname[1]} "$dirInstall/jaguarhadoop/sbin/start-yarn.sh"
