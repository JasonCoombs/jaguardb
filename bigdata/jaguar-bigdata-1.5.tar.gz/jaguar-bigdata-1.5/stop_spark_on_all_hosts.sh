#!/bin/bash

dirInstall=""
if [ -f $HOME/.jaguarbigdatahome ]
then
dirInstall=`cat $HOME/.jaguarbigdatahome`
fi

hname=("")
i=0
while read oneName
do
    hname[i]=$oneName
    i=`expr $i + 1`
done < $dirInstall/jaguarspark/conf/hosts

ssh ${hname[0]} $dirInstall/jaguarspark/sbin/stop-all.sh
