#!/bin/sh

######################################################################################
## DataJaguar, Inc.
##
## Create jaguar client programs jql
##
######################################################################################
JAGUAR_HOME=`cat $HOME/.jaguarhome`
g++ -O3 -o jql.bin $JAGUAR_HOME/lib/jql.o -L$JAGUAR_HOME/lib -lJaguarClient -lGeographic -lpthread
strip jql.bin
echo "Created jql.bin"
