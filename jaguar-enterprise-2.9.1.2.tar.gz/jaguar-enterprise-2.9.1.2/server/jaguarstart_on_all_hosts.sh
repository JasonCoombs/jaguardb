#!/bin/bash

##############################################################################################################
##
##  Start Jaguar Server On All Hosts
##
##  ./jaguarstart_on_all_hosts.sh
##
##############################################################################################################

if [[ ! -f "$HOME/.jaguarhome" ]]; then
	echo "Jaguar has not been installed, quit"
	exit 1
fi

JAGUAR_HOME=`cat $HOME/.jaguarhome`
hostfile="$JAGUAR_HOME/conf/cluster.conf"
allhosts=`cat $hostfile|grep -v '#'`

if [[ -f "$hostfile" ]]; then
    ## echo "OK, $hostfile is found"
	/bin/true
else
    echo "$hostfile is not found, exit"
    exit 1
fi


### reset up ssh keys
if [[ ! -f "$HOME/.jagsetupssh" ]]; then
	echo "Set up ssh public keys on all hosts ..."
	if $JAGUAR_HOME/bin/tools/setupsshkeys -f $hostfile; then
	    echo done > $HOME/.jagsetupssh
	fi
fi

for h in $allhosts; do
    echo "ssh $h $JAGUAR_HOME/bin/jaguarstart"
    ssh $h "$JAGUAR_HOME/bin/jaguarstart" &
done

echo "Jaguar database server is being started on all hosts ..."
echo  " "

