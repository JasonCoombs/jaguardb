#!/bin/bash

###############################################################################################################
##
##  Install script for client 
##
##  ./install.sh     (Install into $HOME direcotyr. You should execute this script on each host in your cluster)
##  ./install.sh     -d <INSTALL_DIR>     (You should execute this script on each host in your cluster)
##
###############################################################################################################

### users can change this to a different directory
export  JAGUAR_HOME=$HOME/jaguar

if [[ "x$1" = "x-d" ]]; then
    JAGUAR_HOME=$2
    if [[ "x$JAGUAR_HOME" = "x" ]]; then
        echo "Usage:  ./install.sh -d <JAGUAR_HOME>"
        echo "Usage:  ./install.sh"
        exit 1
    fi

    if [[ -e "$JAGUAR_HOME" ]]; then
        echo "OK, install jaguar files to $JAGUAR_HOME ..."
    else
        echo "$JAGUAR_HOME does not exist, exit"
        exit 1
    fi
fi

echo "Installing jaguar client in $JAGUAR_HOME/ ..."

/bin/mkdir -p $JAGUAR_HOME/bin
/bin/mkdir -p $JAGUAR_HOME/conf
/bin/mkdir -p $JAGUAR_HOME/data
/bin/mkdir -p $JAGUAR_HOME/pdata
/bin/mkdir -p $JAGUAR_HOME/ndata
/bin/mkdir -p $JAGUAR_HOME/log
/bin/mkdir -p $JAGUAR_HOME/doc
/bin/mkdir -p $JAGUAR_HOME/include
/bin/mkdir -p $JAGUAR_HOME/lib
/bin/mkdir -p $JAGUAR_HOME/tmp
/bin/mkdir -p $JAGUAR_HOME/backup

/bin/cp -f  jql.bin jql.exe jag jbench genrand rlwrap jagimport* jagexport* $JAGUAR_HOME/bin
/bin/cp -f include/*.h $JAGUAR_HOME/include
/bin/cp -f lib/*.a lib/*.so lib/*.jar lib/*.dll lib/jaguarnode.node $JAGUAR_HOME/lib
/bin/cp -f *.ini *.conf $JAGUAR_HOME/conf

/bin/cp -f  JaguarJDBCTest.java example.* README.* comp*.sh goexample.* $JAGUAR_HOME/doc

uo=`uname -o`
if [[ "x$uo" = "xGNU/Linux" ]]; then
    glibcver=`./glibcversion`
    if [[ "x$glibcver" = "x2.12" ]]; then
	    /bin/cp -f lib/2.12/glibc2.12-libJaguarClient.so $JAGUAR_HOME/lib/libJaguarClient.so
	    #/bin/cp -f lib/2.12/jaguarphp.so $JAGUAR_HOME/lib/
    fi
fi

### python so lib
if type python >/dev/null 2>&1
then
	pv=`python --version 2>&1|awk '{print $2}'|cut -d. -f1`
	if (( pv==2 )); then
		/bin/cp -f lib/jaguarpy2.so $JAGUAR_HOME/lib/jaguarpy.so
	else
		/bin/cp -f lib/jaguarpy3.so $JAGUAR_HOME/lib/jaguarpy.so
	fi
fi


echo "Successfully installed jaguar client in $JAGUAR_HOME"

