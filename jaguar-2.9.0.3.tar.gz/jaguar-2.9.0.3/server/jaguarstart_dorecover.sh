#!/bin/bash

##########################################################################################
##
##  Startup script for jaguar server
##
##  If a server had accidently CRASHED, please USE THIS COMMAND to start jaguar
##  on the fixed host or the host that replaces the crashed host.
##
##########################################################################################

### users can change this to a different directory 
. `dirname $0`/jaguarenv

/bin/mkdir -p $JAGUAR_HOME/bin
/bin/mkdir -p $JAGUAR_HOME/conf
/bin/mkdir -p $JAGUAR_HOME/data/system
/bin/mkdir -p $JAGUAR_HOME/data/test
/bin/mkdir -p $JAGUAR_HOME/pdata
/bin/mkdir -p $JAGUAR_HOME/ndata
/bin/mkdir -p $JAGUAR_HOME/log
/bin/mkdir -p $JAGUAR_HOME/doc
/bin/mkdir -p $JAGUAR_HOME/include
/bin/mkdir -p $JAGUAR_HOME/lib
/bin/mkdir -p $JAGUAR_HOME/tmp

hname=`uname -n`
if [[ "x$pid" != "x" ]]; then
	echo "jaguar is already RUNNING on $hname"
	exit 1
fi


cd $JAGUAR_HOME/log
logfile=$JAGUAR_HOME/log/jaguar.log
logfileold=$JAGUAR_HOME/log/jaguar.log.old
logfileoldold=$JAGUAR_HOME/log/jaguar.log.old.old
if [[ -f $logfileold ]]; then
	/bin/mv -f $logfileold $logfileoldold
fi
if [[ -f $logfile ]]; then
	/bin/mv -f $logfile $logfileold
fi

un=`uname -o`
export FROM_SHELL=yes
export DO_RECOVER=yes
if [[ "x$un" = "xMsys" ]]; then
	exec $JAGUAR_HOME/bin/jaguar.exe > $logfile 2>&1 &
elif [[ "x$un" = "xCygwin" ]]; then
	exec $JAGUAR_HOME/bin/jaguar.exe > $logfile 2>&1 &
else 
	exec $JAGUAR_HOME/bin/jaguar.bin > $logfile 2>&1 &
fi

sleep 8
$JAGUAR_HOME/bin/jaguarstatus

