pd=`pwd`
export LD_LIBRARY_PATH=$HOME/jaguar/lib
export GOPATH=$pd
export GOBIN=$GOPATH/bin

go run example.go 8900
