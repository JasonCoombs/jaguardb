package main
import(
  "jaguargo"
  "strconv"
  "flag"
  "fmt"
  "os"
)

func main() {
	flag.Parse()
	ports := flag.Arg(0)
    jdb := jaguargo.New()
	fmt.Printf("port=%s\n", ports )
	port, err := strconv.ParseUint(ports, 0, 64 )
	if err != nil {
		fmt.Printf("error\n" )
		os.Exit(1)
	} 

    jdb.Connect("127.0.0.1", uint(port), "admin", "jaguarjaguarjaguar", "test" )
    jdb.Execute("create table gotab123 (key: uid char(32), value: addr char(128) )" )
    jdb.Query("show databases" )
    for {
            rc := jdb.Reply()
            if rc > 0 {
                jdb.PrintRow()
            } else {
                break
            }
    }

    jdb.Close()

}
