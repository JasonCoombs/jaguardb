#ifndef _MY_PACKAGE_FOO_H_
#define _MY_PACKAGE_FOO_H_

#ifdef __cplusplus
extern "C" {
#endif

	typedef void* Jaguar;
	Jaguar JaguarInit(void);
	void JaguarFree(Jaguar);
	int JaguarConnect(Jaguar, const char *ipaddress, unsigned int port, const char *username, const char *passwd, 
			const char *dbname  );
	int JaguarExecute(Jaguar, const char *query);
	int JaguarQuery(Jaguar, const char *query );
	int JaguarReply(Jaguar );
	const char* JaguarGetSession(Jaguar);
	const char* JaguarGetDatabase(Jaguar);
	void JaguarPrintRow(Jaguar);
	const char* JaguarError(Jaguar);
	int JaguarHasError(Jaguar);
	void JaguarFreeResult(Jaguar);
	char* JaguarGetNthValue(Jaguar, int nth );
	char* JaguarGetValue(Jaguar, const char *name );
	int JaguarGetInt(Jaguar, const char *name, int *value );
	int JaguarGetLong(Jaguar, const char *name, long *value );
	int JaguarGetFloat(Jaguar, const char *name, float *value );
	int JaguarGetDouble(Jaguar, const char *name, double *value );
	const char* JaguarGetMessage(Jaguar);
	void JaguarClose(Jaguar);
	int JaguarGetColumnCount(Jaguar);
	char* JaguarGetCatalogName(Jaguar, int col );
	char* JaguarGetColumnClassName(Jaguar, int col );
	int JaguarGetColumnDisplaySize(Jaguar, int col );
	char* JaguarGetColumnLabel(Jaguar, int col );
	char* JaguarGetColumnName(Jaguar, int col );
	int JaguarGetColumnType(Jaguar, int col );
	char* JaguarGetColumnTypeName(Jaguar, int col );
	int JaguarGetScale(Jaguar, int col );
	char* JaguarGetSchemaName(Jaguar, int col );
	char* JaguarGetTableName(Jaguar, int col );
	bool JaguarIsAutoIncrement(Jaguar, int col );
	bool JaguarIsCaseSensitive(Jaguar, int col );
	bool JaguarIsCurrency(Jaguar, int col );
	bool JaguarIsDefinitelyWritable(Jaguar, int col );
	int  JaguarIsNullable(Jaguar, int col );
	bool JaguarIsReadOnly(Jaguar, int col );
	bool JaguarIsSearchable(Jaguar, int col );
	bool JaguarIsSigned(Jaguar, int col );

#ifdef __cplusplus
}
#endif

#endif
