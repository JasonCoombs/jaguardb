
JAGUAR_HOME=$HOME/jaguar
LIBPATH=$JAGUAR_HOME/lib
export LD_LIBRARY_PATH=$LIBPATH

port=`grep PORT $JAGUAR_HOME/conf/server.conf |grep -v '#' | awk -F= '{print $2}'`

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar:.  example.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. example $port

javac -cp $LIBPATH/jaguar-jdbc-2.0.jar:.  JaguarJDBCTest.java
java -Djava.library.path=$LIBPATH -cp $LIBPATH/jaguar-jdbc-2.0.jar:. JaguarJDBCTest  127.0.0.1 $port

