#include  <stdio.h>
#include  <stdlib.h>
#include  <unistd.h>
#include  <string.h>
#include  <JaguarAPI.h>

int main( int argc, char *argv[] )
{
    const char username[]="admin";
    const char passwd[]="jaguarjaguarjaguar";
    const char dbname[]="test";
	const char  *unixSocket = NULL;
    short port = 8888;
	int rc;
    
	JaguarAPI jag;
    
    if ( ! jag.connect(  "127.0.0.1", port, username, passwd, dbname, unixSocket, 0 ) ) {
        printf( "Error connect\n");
        jag.close( );
        exit(1);
    }
    
	char  query[1024];
	memset( query, 0, 1024 );
	sprintf( query, "create table ccuser ( key: uid char(32), value: zip int, city char(32), name char(32) )" );
    rc = jag.execute( query ); 

	sprintf( query, "insert into ccuser values ( 'larryz', '99842', 'danville', 'larryzx' )" );
    rc = jag.execute( query ); 
	sprintf( query, "insert into ccuser values ( 'mark', '99842', 'sfo', 'Mark Bobo' )" );
    rc = jag.execute( query ); 

    sleep(3);
	sprintf( query, "select * from ccuser");
	rc = jag.query( query );
	if ( ! rc ) {
        printf( "Error jagQuery select [%s]\n", jag.error() );
        jag.close( );
        exit(1);
	}

	char *value;
    while ( jag.reply( ) ) {
		value = jag.getValue( "uid");
		printf("uid='%s' ", value );
		free( value );

		value = jag.getValue( "zip");
		printf("zip='%s' ", value );
		free( value );

		printf("\n"); 
    }

	if ( jag.hasError( ) ) {
		printf("Error: %s\n", jag.error( ) );
	}

    jag.close( );
}

