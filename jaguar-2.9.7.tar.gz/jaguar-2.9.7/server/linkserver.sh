#!/bin/sh

######################################################################################
## DataJaguar, Inc.
##
## Create jaguar server programs
##
######################################################################################
JAGUAR_HOME=`cat $HOME/.jaguarhome`
g++ -O3 -o jaguar.bin $JAGUAR_HOME/lib/jagserv.o -L$JAGUAR_HOME/lib -lJaguarClient -lGeographic -lpthread
strip jaguar.bin 
echo "Created jaguar.bin"
