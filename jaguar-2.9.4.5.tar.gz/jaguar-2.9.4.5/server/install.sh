#!/bin/bash

##############################################################################################################
##
##  Server Installation Script 
##
##  ./install.sh                    (Install to $HOME directory. You should install it on each host in your cluster)
##  ./install.sh -d <INSTALL_DIR>   (Install to INSTALL_DIR. You should install it on each host in your cluster)
##
##############################################################################################################

function localIPs()
{
	un=`uname -o`
    ipv4="[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}\.[[:digit:]]{1,3}"
    loop="127.0.0.1"
    if [[ "x$un" = "xMsys" ]]; then
        g_ips=`ipconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk -F: '{print $2}'`
    elif [[ "x$un" = "GNU/Linux" ]]; then
        g_ips=`/sbin/ifconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk '{print $2}'|cut -d: -f2`
    else
        g_ips=`/sbin/ifconfig|grep -i addr|egrep "$ipv4"|grep -v "$loop"|awk '{print $2}'|cut -d: -f2`
    fi
}


function usage
{
    echo "./install.sh (Install to $HOME directory)"
	echo "./install.sh -d <INSTALL_DIR> -r <SERVER_TOKEN String>"
}

### users can change this to a different directory
export JAGUAR_HOME=$HOME/jaguar
g_ips=""


## Traverse all options given for this shell script
randomstring=""
jaguarhome=""
i=0
for arg in "$@"
do
    i=`expr $i + 1`
    case $arg in
        "-r")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]; then
                randomstring=${!i_next}
            else
				usage
                exit 1
            fi
            ;;

        "-d")
            i_next=`expr $i + 1`
            if [ $i_next -le $# ]; then
                export JAGUAR_HOME=${!i_next}
            else
				usage
                exit 1
            fi
            ;;
        "-help")
            usage
            ;;
        "-h")
            usage
            ;;
        *)
            i_previous=`expr $i - 1`
            if [ ${!i_previous} != "-r" -a ${!i_previous} != "-d" ]; then
            	usage
                exit 1
            fi
            ;;
    esac
done



echo "Installing jaguar server in $JAGUAR_HOME/jaguar ..."
echo $JAGUAR_HOME > $HOME/.jaguarhome

/bin/mkdir -p $JAGUAR_HOME/bin
/bin/mkdir -p $JAGUAR_HOME/conf
/bin/mkdir -p $JAGUAR_HOME/data
/bin/mkdir -p $JAGUAR_HOME/pdata
/bin/mkdir -p $JAGUAR_HOME/ndata
/bin/mkdir -p $JAGUAR_HOME/log
/bin/mkdir -p $JAGUAR_HOME/doc
/bin/mkdir -p $JAGUAR_HOME/include
/bin/mkdir -p $JAGUAR_HOME/lib
/bin/mkdir -p $JAGUAR_HOME/backup


######## copy files  ##############
files=`/bin/ls jaguar* *.sh |uniq`
/bin/cp -f $files sshpass $JAGUAR_HOME/bin
/bin/mkdir -p $JAGUAR_HOME/bin/tools
/bin/cp -f tools/* $JAGUAR_HOME/bin/tools/
/bin/cp -f lib/* $JAGUAR_HOME/lib/
/bin/rm -f $JAGUAR_HOME/bin/install.sh

if [[ ! -f "$JAGUAR_HOME/conf/server.conf" ]]; then
	if [[ "x$randomstring" != "x" ]]; then
		echo "SERVER_TOKEN=$randomstring" >> server.conf
	fi

	/bin/cp -f server.conf $JAGUAR_HOME/conf/
else
	if grep -q SERVER_TOKEN $JAGUAR_HOME/conf/server.conf
	then
		/bin/true
	else
		if [[ "x$randomstring" != "x" ]]; then
			echo "SERVER_TOKEN=$randomstring" >> server.conf
			echo "SERVER_TOKEN=$randomstring" >> $JAGUAR_HOME/conf/server.conf
		fi
	fi

	/bin/cp -f server.conf $JAGUAR_HOME/conf/server.conf.new
	echo "Your exisiting configuration file $JAGUAR_HOME/conf/server.conf is kept the same."
	echo "The new configuration file server.conf is saved as $JAGUAR_HOME/conf/server.conf.new"
fi

/bin/cp -f version.txt $JAGUAR_HOME/conf
/bin/cp -f syncpass.txt $JAGUAR_HOME/conf
/bin/cp -f README.* $JAGUAR_HOME/doc

/bin/mkdir -p $JAGUAR_HOME/data/system
/bin/mkdir -p $JAGUAR_HOME/data/test
touch $JAGUAR_HOME/conf/license.txt
chmod 700 $JAGUAR_HOME

### public and private keys
uo=`uname -o`
if [[ ! -f "$JAGUAR_HOME/conf/private.key" ]]; then
	if [[ "x$uo" = "xGNU/Linux" ]]; then
		cmd="createKeyPair.bin"
	else
		cmd="createKeyPair.exe"
	fi

	$JAGUAR_HOME/bin/tools/$cmd -publickey $JAGUAR_HOME/conf/public.key -privatekey $JAGUAR_HOME/conf/private.key
	chmod 600 $JAGUAR_HOME/conf/private.key
fi

echo "Successfully installed jaguar server in $JAGUAR_HOME/ "
echo "Please install the same package on all the servers in your cluster."
echo "Also, conf/server.conf and conf/cluster.conf must be the same on all servers."

